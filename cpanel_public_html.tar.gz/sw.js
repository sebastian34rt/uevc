/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-b1bafff1'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "0388af8aa63ec12b5675603ac6d46baf"
  }, {
    "url": "pwa-512x512.png",
    "revision": "22ff6b0fd690e842abaae0bca00907df"
  }, {
    "url": "pwa-192x192.png",
    "revision": "8f3f4cae41e8161e6e32709951294dbe"
  }, {
    "url": "logo.png",
    "revision": "cd8de8d0c8126cc5595c4717a45e827a"
  }, {
    "url": "index.html",
    "revision": "6b59a53af55d9c520617407a83c98602"
  }, {
    "url": "favicon.ico",
    "revision": "938abab1995d63aa46e2394cffe50475"
  }, {
    "url": "exposicion.html",
    "revision": "abf2a87ae177c055e2ca1658fa12ff31"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "7ec874aac1f7147424e48b1c284115a3"
  }, {
    "url": "9.jpg",
    "revision": "7411c938c9fe5cd8397641a60f313d41"
  }, {
    "url": "8.jpg",
    "revision": "488f248f8e60693ff6af73b85232927c"
  }, {
    "url": "7.jpg",
    "revision": "d28d358c965c8ee2251d0d613d6be172"
  }, {
    "url": "6.jpg",
    "revision": "0980338092bf09daa87c846cff12bd8b"
  }, {
    "url": "5.jpg",
    "revision": "24f24efddae54929f1d1dbf2c7d87d92"
  }, {
    "url": "4.jpg",
    "revision": "4791ab8dec35b5e8af46a986fd2e9626"
  }, {
    "url": "3.jpg",
    "revision": "5da0e418a2abef4f3150090c18d41d05"
  }, {
    "url": "2.jpg",
    "revision": "fa902a43a44107d5d74f93ca4e5177ba"
  }, {
    "url": "10.jpg",
    "revision": "b2b6fd9feece3f493bfb0e4f7b0749d2"
  }, {
    "url": "1.jpg",
    "revision": "9ef9b78d417bff1ce3e665c6600514ec"
  }, {
    "url": "assets/workbox-window.prod.es5-BBnX5xw4.js",
    "revision": null
  }, {
    "url": "assets/trophy-CKM-6-WU.js",
    "revision": null
  }, {
    "url": "assets/sparkles-Crp4kijf.js",
    "revision": null
  }, {
    "url": "assets/purify.es-CAi2OJFm.js",
    "revision": null
  }, {
    "url": "assets/plus-BdvTdC3N.js",
    "revision": null
  }, {
    "url": "assets/phone-nTkPKIny.js",
    "revision": null
  }, {
    "url": "assets/mail-ChxRxuit.js",
    "revision": null
  }, {
    "url": "assets/loader-circle-BUv2yQUK.js",
    "revision": null
  }, {
    "url": "assets/lightbulb-D-mBiFVO.js",
    "revision": null
  }, {
    "url": "assets/index.es-DDIkInur.js",
    "revision": null
  }, {
    "url": "assets/index-DyyotjtD.js",
    "revision": null
  }, {
    "url": "assets/index-C7A7LXdN.css",
    "revision": null
  }, {
    "url": "assets/graduation-cap-9KzVmiWS.js",
    "revision": null
  }, {
    "url": "assets/funnel-9VG4GnJG.js",
    "revision": null
  }, {
    "url": "assets/file-text-CGAPSx5K.js",
    "revision": null
  }, {
    "url": "assets/eye-DHQOlKyd.js",
    "revision": null
  }, {
    "url": "assets/external-link-DPB0axlD.js",
    "revision": null
  }, {
    "url": "assets/copy-whpoKEZl.js",
    "revision": null
  }, {
    "url": "assets/clock-D95bxBin.js",
    "revision": null
  }, {
    "url": "assets/circle-alert-C22cUo4g.js",
    "revision": null
  }, {
    "url": "assets/arrow-left-CnKoTQnM.js",
    "revision": null
  }, {
    "url": "assets/Testimonials-8DjCgM5b.js",
    "revision": null
  }, {
    "url": "assets/TermsOfService-D_Cfvyh3.js",
    "revision": null
  }, {
    "url": "assets/StaffDirectory-CJ5kT8qZ.js",
    "revision": null
  }, {
    "url": "assets/SorteosPublicPage-c1Pos3VF.js",
    "revision": null
  }, {
    "url": "assets/Programs-CoIV6DDE.js",
    "revision": null
  }, {
    "url": "assets/PrivacyPolicy-DQwy1aGI.js",
    "revision": null
  }, {
    "url": "assets/Platforms-oxZfd6c8.js",
    "revision": null
  }, {
    "url": "assets/News-BvjsD4lu.js",
    "revision": null
  }, {
    "url": "assets/Login-BDBv4aP9.js",
    "revision": null
  }, {
    "url": "assets/LiveStream-CnGszbgW.js",
    "revision": null
  }, {
    "url": "assets/HelpDesk-WN2Wl29o.js",
    "revision": null
  }, {
    "url": "assets/Gallery-DrYWlBKC.js",
    "revision": null
  }, {
    "url": "assets/Enrollment-DQsJjxFT.js",
    "revision": null
  }, {
    "url": "assets/Contact-3A78iRjp.js",
    "revision": null
  }, {
    "url": "assets/Calendar-CiVTdQ17.js",
    "revision": null
  }, {
    "url": "assets/AdminHelpdeskConfig-Ch2fFshj.js",
    "revision": null
  }, {
    "url": "assets/AdminDashboard-DBNmsTB9.js",
    "revision": null
  }, {
    "url": "assets/About-BnpkWuKU.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "7ec874aac1f7147424e48b1c284115a3"
  }, {
    "url": "favicon.ico",
    "revision": "938abab1995d63aa46e2394cffe50475"
  }, {
    "url": "logo.png",
    "revision": "cd8de8d0c8126cc5595c4717a45e827a"
  }, {
    "url": "pwa-192x192.png",
    "revision": "8f3f4cae41e8161e6e32709951294dbe"
  }, {
    "url": "pwa-512x512.png",
    "revision": "22ff6b0fd690e842abaae0bca00907df"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "0388af8aa63ec12b5675603ac6d46baf"
  }, {
    "url": "manifest.webmanifest",
    "revision": "df3dfda12e581588c0e2a9f23abd9fa5"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/\.(?:png|jpg|jpeg|svg|gif|webp)$/i, new workbox.StaleWhileRevalidate({
    "cacheName": "static-images-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 60,
      maxAgeSeconds: 2592000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
